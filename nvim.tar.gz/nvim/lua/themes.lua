-- Themes

-- TokioNight
vim.g.tokyonight_style = 'night'
vim.g.tokyonight_italic_comments = false
vim.cmd [[colorscheme tokyonight]]

-- Material
-- vim.g.material_style = 'oceanic'
-- vim.cmd [[colorscheme material]]
