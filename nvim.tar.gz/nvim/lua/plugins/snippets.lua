-- LuaSnip

require('luasnip.loaders.from_vscode').lazy_load()
require('luasnip').filetype_extend("python", {'pytorch'})
